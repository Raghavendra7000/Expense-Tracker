// Select Elements
const menuBtn = document.querySelector(".menu");
const sidebar = document.querySelector(".sidebar");

const profileBtn = document.querySelector(".profile");
const profileMenu = document.querySelector(".rightbar");

const logoutBtn = document.querySelector(".logout");
const addTrans = document.querySelector(".transact");
const transPage = document.querySelector(".add-container");

menuBtn.addEventListener("click", () => {
  sidebar.classList.toggle("inactive");
});

profileBtn.addEventListener("click", (e) => {
  e.stopPropagation();

  profileMenu.classList.toggle("inactive");
});

document.addEventListener("click", (e) => {
  if (!profileMenu.contains(e.target) && !profileBtn.contains(e.target)) {
    profileMenu.classList.add("inactive");
  }
});

// ================================
// Logout
// ================================

logoutBtn.addEventListener("click", () => {
  const answer = confirm("Do you want to Logout?");

  if (answer) {
    window.location.href = "login.html";
  }
});
addTrans.addEventListener("click", () => {
  transPage.classList.toggle("inactive");
});
